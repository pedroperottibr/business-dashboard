import React, { useState } from "react";
import { Line, Pie } from "react-chartjs-2";

function App() {
  const [revenue, setRevenue] = useState([500, 700, 400, 600, 900, 800, 750]);
  const [expenses, setExpenses] = useState([40, 30, 20, 10]);

  const revenueData = {
    labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    datasets: [
      {
        label: "Daily Revenue",
        data: revenue,
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 2,
      },
    ],
  };

  const expenseData = {
    labels: ["Marketing", "Salaries", "Office Supplies", "Other"],
    datasets: [
      {
        data: expenses,
        backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0"],
      },
    ],
  };

  return (
    <div style={{ padding: "20px", backgroundColor: "#1e1e2f", color: "#fff", minHeight: "100vh" }}>
      <h1 style={{ textAlign: "center" }}>Business Dashboard</h1>
      <form style={{ marginBottom: "20px" }}>
        <label style={{ display: "block", marginBottom: "10px" }}>
          Update Daily Revenue (comma-separated values):
          <input
            type="text"
            onChange={(e) =>
              setRevenue(e.target.value.split(",").map((num) => parseFloat(num)))
            }
            placeholder="e.g., 500,700,400,600,900,800,750"
            style={{
              width: "100%",
              padding: "10px",
              marginTop: "5px",
              borderRadius: "5px",
            }}
          />
        </label>
        <label style={{ display: "block", marginBottom: "10px" }}>
          Update Expenses (comma-separated percentages):
          <input
            type="text"
            onChange={(e) =>
              setExpenses(e.target.value.split(",").map((num) => parseFloat(num)))
            }
            placeholder="e.g., 40,30,20,10"
            style={{
              width: "100%",
              padding: "10px",
              marginTop: "5px",
              borderRadius: "5px",
            }}
          />
        </label>
      </form>
      <div style={{ display: "flex", gap: "20px" }}>
        <div style={{ flex: 1, backgroundColor: "#222", padding: "20px", borderRadius: "10px" }}>
          <h3>Daily Revenue</h3>
          <Line data={revenueData} />
        </div>
        <div style={{ flex: 1, backgroundColor: "#222", padding: "20px", borderRadius: "10px" }}>
          <h3>Business Expenses</h3>
          <Pie data={expenseData} />
        </div>
      </div>
    </div>
  );
}

export default App;
